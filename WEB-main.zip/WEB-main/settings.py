import os


HOST = "10.0.2.15"
PORT = 80
WORKING_DIR = os.getcwd()
REQUEST_SIZE = 25240
